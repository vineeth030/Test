define([
    'jquery',
    'knockout',
    'Swissup_CheckoutSuccess/lib/dragula/dragula',
    'mage/utils/wrapper'
], function ($, ko, dragula, wrapper) {
    'use strict';

    function DragulaElementViewModel(configValue, availableBlocks) {
        var self = this;

        self.availableBlocks = availableBlocks;

        self.containers = $.map($.parseJSON(configValue), function (element) {
            element.children = ko.observableArray(element.children);
            return element;
        });

        self.removeChild = function (block, container) {
            container.children.remove(block);
        };

        self.addChild = function (block, container, beforeBlock) {
            var index;
            if (beforeBlock) {
                index = container.children().indexOf(beforeBlock);
                container.children.splice(index, 0, block);
            } else {
                container.children.push(block);
            }
        };

        self.layoutConfigValue = ko.computed(function () {
            return ko.toJSON(self.containers);
        });

        self.onDragulaDrop = function (el, target, source, sibling) {
            var block;
            if (!target) {
                return;
            }

            if ($(source).hasClass('copy-only')) {
                // create new ko data block
                block = {'name': $(el).data('name')};
            } else {
                // remove block from old container
                block = ko.dataFor(el);
                self.removeChild(block, ko.dataFor(source));
            }

            // add block to new container
            self.addChild(
                block,
                ko.dataFor(target),
                sibling ? ko.dataFor(sibling) : null
            );
            // remove droped element to prevent block duplication
            $(el).remove();
        };
    }

    function prepareDragulaElement(options) {
        var dargulaElement = $(
            '<div/>',
            {
                class: 'dragula-element',
                'data-bind': "template: { name: 'layout-template', foreach: containers}"
            }
        );
        if (options.disabled) {
            dargulaElement.addClass('disabled');
        }

        return dargulaElement;
    }

    return {
        successPageLayout: function (options, element) {
            this.initialize(options, element);

            // apply knockout binding
            var dragulaVM = new DragulaElementViewModel(
                this.configField.val(),
                options.availableBlocks
            );
            ko.applyBindings(dragulaVM, this.element);

            // initialize dragula
            this.drake = dragula(
                $('#'+options.parentId).find('.dragula-element').children().toArray(),
                {
                    copy: function (el, source) {
                        return $(source).hasClass('copy-only');
                    },
                    accepts: function (el, target) {
                        return !$(target).hasClass('copy-only');
                    }
                }
            ).on('drop', dragulaVM.onDragulaDrop);

            // wrap toggle function to enable/disable dragula element
            toggleValueElements = wrapper.wrap(
                toggleValueElements,
                function (
                    callOriginal, checkbox, container, excludedElements, checked
                ) {
                    var result = callOriginal(
                        checkbox,
                        container,
                        excludedElements,
                        checked
                    );
                    $(container).find('.dragula-element').toggleClass('disabled');
                    return result;
                }
            );

            this.hideSpinner();
        },

        initialize: function (options, element) {
            this.element = element;
            this.options = options;
            this.configField = $(this.element)
                .children('textarea')
                .attr('data-bind', 'value: layoutConfigValue')
                .hide();
            prepareDragulaElement(options).insertAfter(this.configField);
        },

        hideSpinner: function () {
            $(this.element).children('[data-role="spinner"]').hide();
        }
    };

});
