define([
    'jquery',
    'Magento_Ui/js/modal/alert'
], function ($, alert) {
    'use strict';

    return {
        successPagePreview: function (options, element) {
            this.target = $(options.target);
            this.source = $(options.source);
            this.previewUrl = options.previewUrl;
            $(element).on('click', this.saveAndPraview.bind(this));
        },

        saveAndPraview: function () {
            // configForm is global variable
            if (configForm.validation('isValid')) {
                // save config
                $.ajax({
                    method: 'POST',
                    url: configForm.attr('action'),
                    data: configForm.serialize(),
                    context: this
                }).done(function (response) {
                    if (typeof response == 'object') {
                        this.handleJsonResponse(response);
                    } else {
                        this.handleHtmlResponse(response);
                    }

                    this.spinnerHide();
                });

                this.target.find('iframe').remove();
                this.spinnerShow();
            } else {
                // todo: config form is invalid
            }
        },

        spinnerShow: function () {
            this.target.find('[data-role="iframe-placeholder"]')
                .show()
                .css('position', '');
        },

        spinnerHide: function () {
            $('html, body').animate({
                scrollTop: this.target.offset().top - 120
            },600);
            this.target.find('[data-role="iframe-placeholder"]')
                .css('position', 'absolute')
                .delay(6000)
                .hide(0); // pass 0 so delay could work on hide
        },

        getNewHashAndExpire: function (html) {
            html = html.replace(/(\r\n|\n|\r)/gm, ''); // remove newlines
            var regExp = new RegExp('<tr id="'+this.source.parent().attr('id')+'">(.*?)</tr>');
            var matches = regExp.exec(html);
            if (!matches || typeof matches[0] == 'undefined') {
                return;
            }

            return $(matches[0]).find('.value input[type="hidden"]');
        },

        handleHtmlResponse: function (html) {
            // start preview on successful save
            var iframe = $('<iframe/>',{
                src: this.previewUrl.replace(
                        '{{orderNumber}}',
                        this.source.find('input[id$=order_to_preview]').val()
                    ).replace(
                        '{{previewHash}}',
                        this.source.find('input[id$=preview_hash]').val()
                    )
            }).css({
                'width': '100%',
                'border': '1px solid #d6d6d6',
                'min-height': '700px'
            });
            this.target.append(iframe);
            // get new values for preview hash and preview expire
            this.source.find('input[type="hidden"]').remove();
            this.source.append(this.getNewHashAndExpire(html));
        },

        handleJsonResponse: function (json) {
            if (json.error) {
                alert({ title: 'Error', content: json.message });
            } else if (json.ajaxExpired) {
                window.location.href = json.ajaxRedirect;
            }
        }
    };

});
