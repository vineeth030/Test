var config = {
    map: {
        '*': {
            'successPageLayout': 'Swissup_CheckoutSuccess/js/success-page/layout',
            'successPagePreview': 'Swissup_CheckoutSuccess/js/success-page/preview'
        }
    }
};
