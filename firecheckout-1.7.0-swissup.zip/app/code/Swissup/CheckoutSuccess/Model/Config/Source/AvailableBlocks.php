<?php
namespace Swissup\CheckoutSuccess\Model\Config\Source;

class AvailableBlocks implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * List of available blocks on success page
     *
     * @var array
     */
    protected $options;

    /**
     * Get options as array of [value, label]
     *
     * @return array
     */
    public function toOptionArray()
    {
        $arr = [];
        foreach ($this->toOptions() as $key => $value) {
            $arr[] = ['value' => $key, 'label' =>$value];
        }
        return $arr;
    }

    public function toOptions()
    {
        if (!isset($this->options)) {
            $this->options = [
                'thank.you' =>  __('"Thank you" note'),
                'order.date' => __('Order Date'),
                'sales.order.view' => __('Order Items'),
                'sales.order.info' => __('Order Info'),
                'create.account' => __('Create Account'),
                'order.success.additional.info' => __('Additional Info'),
                'checkout.additional.cms.top' => __('CMS: Above info'),
                'checkout.additional.cms.bottom' => __('CMS: Below info'),
            ];
        }

        return $this->options;
    }
}
