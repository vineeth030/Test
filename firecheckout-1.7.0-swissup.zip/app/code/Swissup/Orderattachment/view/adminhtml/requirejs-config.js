var config = {
    map: {
        '*': {
            orderAttachment : 'Swissup_Orderattachment/js/order-attachment'
        }
    }
};
