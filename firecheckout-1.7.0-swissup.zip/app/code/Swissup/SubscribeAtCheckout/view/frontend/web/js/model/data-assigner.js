define([
    'uiRegistry'
], function (registry) {
    'use strict';

    return function (paymentData) {
        if (!paymentData.extension_attributes) {
            paymentData.extension_attributes = {};
        }

        var path = 'checkout.steps.shipping-step.shippingAddress.before-form.subscribe-at-checkout';

        paymentData.extension_attributes.swissup_subscribe_at_checkout =
            registry.get(path).checked();
    };
});
