<?php

namespace Swissup\SubscriptionChecker\Controller\Adminhtml;

abstract class Subscription extends \Magento\Backend\App\Action
{
    const MODULE_CODE = 'Swissup_Subscription';

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry
    ) {
        $this->coreRegistry = $coreRegistry;
        parent::__construct($context);
    }
}
