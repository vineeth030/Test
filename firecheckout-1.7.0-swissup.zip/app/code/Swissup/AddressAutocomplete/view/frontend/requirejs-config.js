var config = {
    paths : {
        async: 'Swissup_AddressAutocomplete/js/requirejs-plugins/async',
        goog: 'Swissup_AddressAutocomplete/js/requirejs-plugins/goog',
        propertyParser: 'Swissup_AddressAutocomplete/js/requirejs-plugins/propertyParser'
    },
    map : {
        '*' : {
            'AddressAutocomplete': 'Swissup_AddressAutocomplete/js/address-autocomplete'
        }
    }
}