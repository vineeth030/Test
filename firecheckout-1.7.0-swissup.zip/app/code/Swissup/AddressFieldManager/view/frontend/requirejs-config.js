var config = {
    config: {
        // left to overwrite outdated code
    }
};
