define(
    [
        'jquery',
        'uiRegistry',
        'mage/validation'
    ],
    function ($, registry) {
        'use strict';

        var checkoutConfig = window.checkoutConfig,
            swissupCheckoutFieldsEnabled = checkoutConfig ? checkoutConfig.swissupCheckoutFieldsEnabled : {};

        return {
            /**
             * Validate checkout fields
             *
             * @returns {boolean}
             */
            validate: function() {
                if (!swissupCheckoutFieldsEnabled) {
                    return true;
                }

                var checkoutProvider = registry.get('checkoutProvider');
                if (typeof checkoutProvider.get('swissupCheckoutFields') === "undefined") {
                    return true;
                }
                checkoutProvider.set('params.invalid', false);
                if (checkoutProvider.get('swissupCheckoutFields')) {
                    checkoutProvider.trigger('swissupCheckoutFields.data.validate');
                    var result = !checkoutProvider.get('params.invalid');
                    if (!result) {
                        this.scrollToError();
                    }
                    return result;
                };
                return false;
            },

            isElementVisibleInViewport: function(el) {
                var rect = el.getBoundingClientRect(),
                    viewport = {
                        width: $(window).width(),
                        height: $(window).height()
                    };

                return (
                    rect.top  >= 0 &&
                    rect.left >= 0 &&
                    rect.bottom <= viewport.height &&
                    rect.right  <= viewport.width
                );
            },

            /**
             * Scroll to error if it's not visible in viewport
             */
            scrollToError: function() {
                var messages = $('div.mage-error:visible, .firecheckout-msg:visible');
                if (!messages.length) {
                    return;
                }

                var timeout = 0,
                    visibleMessage = messages.toArray().find(this.isElementVisibleInViewport);

                if (!visibleMessage) {
                    visibleMessage = messages.first();
                    timeout = 200;
                    $('html, body').animate({
                        scrollTop: visibleMessage.offset().top - 70
                    }, timeout);
                }
                setTimeout(function() {
                    $(visibleMessage).addClass('firecheckout-shake')
                        .one(
                            'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend',
                            function() {
                                $(this).removeClass('firecheckout-shake');
                            }
                        );
                }, timeout);
            }
        }
    }
);
