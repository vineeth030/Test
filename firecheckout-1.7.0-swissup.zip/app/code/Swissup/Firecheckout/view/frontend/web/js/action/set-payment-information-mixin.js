define([
    'jquery',
    'mage/utils/wrapper',
    'Magento_Checkout/js/model/quote',
    'Swissup_Firecheckout/js/model/firecheckout'
], function ($, wrapper, quote, firecheckout) {
    'use strict';

    var checkoutConfig = window.checkoutConfig;

    return function (setPaymentInformatrion) {
        if (!checkoutConfig.isFirecheckout) {
            return setPaymentInformatrion;
        }

        /** Override place-order-mixin for set-payment-information action as they differs only by method signature */
        return wrapper.wrap(setPaymentInformatrion, function (originalAction, messageContainer, paymentData) {
            return $.when(firecheckout.submitShippingInformation())
                .then(function() {
                    return originalAction(messageContainer, paymentData);
                });
        });
    };
});
