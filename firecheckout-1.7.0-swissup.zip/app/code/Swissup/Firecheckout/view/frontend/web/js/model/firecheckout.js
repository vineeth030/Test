define([
    'jquery',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/resource-url-manager',
    'mage/storage',
    'Swissup_Firecheckout/js/model/validator',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/action/set-shipping-information',
    'Magento_Checkout/js/model/payment-service'
], function(
    $,
    quote,
    resourceUrlManager,
    storage,
    validator,
    errorProcessor,
    fullScreenLoader,
    setShippingInformationAction,
    paymentService
) {
    'use strict';

    return {
        /**
         * Place Order method
         */
        placeOrder: function() {
            if (!validator.validate()) { // in case if payment method is not selected
                return false;
            }

            // quote.paymentMethod.placeOrder();
            $('.action.checkout', '.payment-method._active').click();
        },

        /**
         * @return {Deferred}
         */
        submitShippingInformation: function() {
            if (!quote.isVirtual()) {
                paymentService.doNotUpdate = true;
                return setShippingInformationAction()
                    .then(function() {
                        delete paymentService.doNotUpdate;
                    });
            } else {
                return true;
            }
        }
    };
});
