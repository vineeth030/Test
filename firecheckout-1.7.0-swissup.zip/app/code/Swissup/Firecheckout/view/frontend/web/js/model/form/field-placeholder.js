define([
    'underscore',
    'Magento_Ui/js/lib/view/utils/async',
    'ko',
    'mage/translate'
], function (_, $, ko) {
    'use strict';

    /**
     * Add placeholder attribute to the form fields
     */
    return {
        init: function (containers) {
            var self = this;

            var selector = [],
                fields = [
                    'input',
                    'select',
                    'textarea'
                ];
            _.each(containers, function (container) {
                _.each(fields, function (field) {
                    selector.push(container + ' ' + field);
                });
            });

            $.async({
                selector: selector.join(','),
                ctx: $('.checkout-container').get(0)
            }, function (el) {
                _.defer(self.handle.bind(self), $(el));
            });
        },

        /**
         * @param  {jQuery} el
         * @return {void}
         */
        handle: function (el) {
            if (!el || el.get(0).type === 'hidden') {
                return;
            }

            if (el.attr('placeholder') && el.get(0).name !== 'password') {
                // password has a placeholder="optional" and it's not acceptible
                // when labels are hidden
                return;
            }

            var koElement = ko.dataFor(el.get(0));
            if (koElement) {
                if (typeof koElement.placeholder === 'function') {
                    koElement.placeholder(this.getPlaceholderText(el))
                } else {
                    koElement.placeholder = this.getPlaceholderText(el);
                }
            }
            el.attr('placeholder', this.getPlaceholderText(el));

            // fill empty option with label text,
            // otherwise input will be empty and without label
            if (el.get(0).tagName.toLowerCase() === 'select') {
                el.find('option[value=""]').each(function () {
                    if (!$(this).text().trim()) {
                        $(this).text($.mage.__('Please Select'));
                    }
                });
            }
        },

        /**
         * @param  {jQuery} el
         * @return {String}
         */
        getPlaceholderText: function (el) {
            var inputBox = this.getInputBox(el);
            if (!inputBox) {
                return '';
            }

            var text = inputBox.find('.label').text().trim();
            if (!text) {
                return;
            }

            if (inputBox.hasClass('_required')) {
                text += ' *';
            }

            return text;
        },

        /**
         * @param  {jQuery} el
         * @return {jQuery}
         */
        getInputBox: function (el) {
            return el.closest('.field');
        }
    }
});
