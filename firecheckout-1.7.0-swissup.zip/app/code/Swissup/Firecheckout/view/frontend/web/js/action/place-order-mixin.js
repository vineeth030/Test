define([
    'jquery',
    'mage/utils/wrapper',
    'Magento_Checkout/js/model/quote',
    'Swissup_Firecheckout/js/model/firecheckout'
], function ($, wrapper, quote, firecheckout) {
    'use strict';

    var checkoutConfig = window.checkoutConfig;

    return function (placeOrderAction) {
        if (!checkoutConfig.isFirecheckout) {
            return placeOrderAction;
        }

        /** Override default place order action to save shipping address changes */
        return wrapper.wrap(placeOrderAction, function(originalAction, paymentData, messageContainer) {
            return $.when(firecheckout.submitShippingInformation())
                .then(function() {
                    return originalAction(paymentData, messageContainer);
                });
        });
    };
});
