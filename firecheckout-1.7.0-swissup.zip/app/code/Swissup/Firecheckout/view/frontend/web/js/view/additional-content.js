define([
    'uiComponent'
], function(Component) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Swissup_Firecheckout/additional-content',
            content: null
        }
    });
});
