define([
    'jquery',
    'underscore',
    'uiComponent',
    'uiRegistry',
    'Magento_Checkout/js/model/quote',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/model/payment/method-list',
    'Magento_Checkout/js/model/shipping-service',
    'Swissup_Firecheckout/js/model/validator',
    'Magento_Checkout/js/model/address-converter',
    'Magento_Checkout/js/action/select-shipping-address',
    'Magento_Checkout/js/action/select-billing-address',
    'Swissup_Firecheckout/js/action/set-shipping-method',
    'Swissup_Firecheckout/js/custom'
], function(
    $,
    _,
    Component,
    registry,
    quote,
    customer,
    paymentMethods,
    shippingService,
    validator,
    addressConverter,
    selectShippingAddress,
    selectBillingAddress,
    setShippingMethodAction
) {
    'use strict';

    return Component.extend({
        defaults: {
            plugins: {}
        },

        sameAsShippingObservers: [],

        /**
         * Initialize quote namespace with firecheckout storage
         *
         * @return void
         */
        initQuote: function() {
            quote.firecheckout = {
                state: {
                    savingShippingMethod: false
                },
                // last selected values are stored in memo
                memo: {
                    shippingMethod: {},
                    shippingAddress: {}
                }
            };
        },

        initialize: function() {
            this._super();

            this.initQuote();

            if (quote.isVirtual()) {
                $('body').addClass('firecheckout-quote-virtual');
            } else {
                this.addShippingHandlers();
            }

            quote.paymentMethod.subscribe(function(method) {
                validator.removeNotice('#co-payment-form');
            }, this);

            this.initPlugins();
        },

        /**
         * Run custom plugins
         *
         * @return {void}
         */
        initPlugins: function() {
            _.each(this.plugins, function(el, index, list) {
                if (el.pluginDisabled || !el.plugin) {
                    return;
                }

                require([el.plugin], function(plugin) {
                    plugin.init.apply(plugin, el.params);
                });
            });
        },

        /**
         * Add shipping method/address related listeners
         */
        addShippingHandlers: function() {
            this.debouncedSaveShippingMethod = _.debounce(
                this.saveShippingMethod.bind(this),
                200
            );

            quote.shippingMethod.subscribe(function(method) {
                validator.removeNotice('#co-shipping-method-form');
                if (shippingService.isLoading()) {
                    return;
                }
                this.applyShippingMethod();
            }, this);
            shippingService.isLoading.subscribe(function(flag) {
                if (flag) {
                    return;
                }
                this.applyShippingMethod();
            }, this);

            this.addSameAsShippingObservers();

            quote.paymentMethod.subscribe(function(method) {
                this.toggleEqualAddressClassName(method);
            }, this);

            // Instant copy to "quote shipping address object" to sync with billing address
            if (!customer.isLoggedIn()) {
                var debouncedSelectShippingAddress = _.debounce(selectShippingAddress, 2000);

                registry.async('checkoutProvider')(function (checkoutProvider) {
                    checkoutProvider.on('shippingAddress', function (shippingAddressData) {
                        var shippingAddress = quote.shippingAddress(),
                            addressData = addressConverter.formAddressDataToQuoteAddress(shippingAddressData);

                        if (!shippingAddress) {
                            return;
                        }

                        for (var field in addressData) {
                            if (addressData.hasOwnProperty(field) &&
                                shippingAddress.hasOwnProperty(field) &&
                                typeof addressData[field] != 'function'
                            ) {
                                shippingAddress[field] = addressData[field];
                            }
                        }

                        debouncedSelectShippingAddress(shippingAddress);
                    });
                });
            }

            // Instant billing address update
            quote.shippingAddress.subscribe(function(address) {
                var method = quote.paymentMethod(),
                    billingAddressNames = [
                        'checkout.steps.billing-step.payment.afterMethods.billing-address-form'
                    ];

                if (!method) {
                    _.each(paymentMethods(), function (paymentMethodData) {
                        billingAddressNames.push(
                            'checkout.steps.billing-step.payment.payments-list.'
                            + paymentMethodData.method
                            + '-form'
                        );
                    });
                } else {
                    var billingNameForCurrentPayment =
                        'checkout.steps.billing-step.payment.payments-list.'
                        + method.method
                        + '-form';

                    billingAddressNames.push(billingNameForCurrentPayment);

                    // fix for paypal express and other payments without visible address
                    if (!registry.get(billingNameForCurrentPayment)) {
                        selectBillingAddress(quote.shippingAddress());
                    }
                }

                _.each(billingAddressNames, function(name) {
                    registry.get(name, function(billingAddress) {
                        if (billingAddress.isAddressSameAsShipping()) {
                            selectBillingAddress(quote.shippingAddress());
                        }
                    });
                });

            }, this);
        },

        applyShippingMethod: function() {
            if (!shippingService.getShippingRates()().length) {
                quote.shippingMethod(null);
            }
            this.debouncedSaveShippingMethod();
        },

        /**
         * Saves shipping information with additional fixes:
         *  - check for ajax state in case of request is already sent
         *  - give 50ms time before making a request (for the form filler plugins)
         *
         * @return void
         */
        saveShippingMethod: function() {
            // prevent multiple ajax requests with the same parameters
            if (false !== quote.firecheckout.state.savingShippingMethod) {
                var methodSent = quote.firecheckout.state.savingShippingMethod;
                if (!methodSent && !quote.shippingMethod()) {
                    return;
                }
                if (methodSent && quote.shippingMethod() &&
                    (methodSent.method_code === quote.shippingMethod().method_code) &&
                    (methodSent.amount === quote.shippingMethod().amount)) {

                    return;
                }
            }

            // shipping titles are updated by ko, so we shoud care about amount only
            if (!this.shouldSaveShippingInformation()) {
                this._log('SKIP', quote.shippingMethod());
                return;
            }

            this._log('APPLY', quote.shippingMethod());
            quote.firecheckout.state.savingShippingMethod = quote.shippingMethod();

            // give some time for the form fillers
            setTimeout(function() {
                setShippingMethodAction()
                    .done(function() {
                        quote.firecheckout.state.savingShippingMethod = false;
                        quote.firecheckout.memo.shippingMethod = quote.shippingMethod();

                        var address = quote.shippingAddress();
                        quote.firecheckout.memo.shippingAddress = {
                            'countryId' : address.countryId,
                            'postcode'  : address.postcode,
                            'region'    : address.region,
                            'regionId'  : address.regionId,
                            'vatId'     : address.vatId
                        };
                    })
                    .fail(function() {
                        quote.firecheckout.state.savingShippingMethod = false;
                    });
            }, 50);
        },

        shouldSaveShippingInformation: function() {
            var memo = quote.firecheckout.memo;
            if (!memo.shippingMethod && !quote.shippingMethod()) {
                // method is not available
                return false;
            }
            if (!memo.shippingMethod || !quote.shippingMethod()) {
                // method is changed from null to normal or vice versa
                return true;
            }

            if (memo.shippingMethod.amount !== quote.shippingMethod().amount) {
                return true;
            }
            if (memo.shippingMethod.method_code === quote.shippingMethod().method_code) {
                return false;
            }

            // check for address sensitive data
            var addressFields = [
                'countryId',
                'postcode',
                'region',
                'regionId',
                'vatId'
            ];
            return addressFields.some(function(field, index) {
                return memo.shippingAddress[field] !== quote.shippingAddress()[field];
            });
        },

        /**
         * Toggle 'equal-billing-shipping' classname according to
         * billingAddress.isAddressSameAsShipping
         *
         * @return boolean
         */
        toggleEqualAddressClassName: function(method) {
            registry.get(
                'checkout.steps.billing-step.payment.afterMethods.billing-address-form',
                function(billingAddress) {
                    billingAddress.isAddressSameAsShipping.subscribe(function(flag) {
                        $('body').toggleClass('equal-billing-shipping', flag);
                    });
                }
            );

            method = method || quote.paymentMethod();
            if (!method) {
                return;
            }
            registry.get(
                'checkout.steps.billing-step.payment.payments-list.' + method.method + '-form',
                function(billingAddress) {
                    var flag = billingAddress.isAddressSameAsShipping();
                    $('body').toggleClass('equal-billing-shipping', flag);
                }
            );
            return true;
        },

        /**
         * Add observers to each payment method to toggle 'equal-billing-shipping'
         * class name on "My billing and shipping address are the same" state update
         *
         * @param void
         */
        addSameAsShippingObservers: function() {
            registry.get(
                'checkout.steps.billing-step.payment.afterMethods.billing-address-form',
                function(billingAddress) {
                    billingAddress.isAddressSameAsShipping.subscribe(function(flag) {
                        $('body').toggleClass('equal-billing-shipping', flag);
                    });
                }
            );

            _.each(paymentMethods(), function (paymentMethodData) {
                registry.get(
                    'checkout.steps.billing-step.payment.payments-list.' + paymentMethodData.method + '-form',
                    function(billingAddress) {
                        billingAddress.isAddressSameAsShipping.subscribe(function(flag) {
                            $('body').toggleClass('equal-billing-shipping', flag);
                        });
                    }
                );
            });
        },

        _log: function(title, data) {
            if (window.location.hash !== '#development') {
                return;
            }

            var date = new Date();
            console.log(date.getSeconds() + ': ' + title);
            console.log(data);
        }
    });
});
