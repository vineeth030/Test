define([
    'underscore',
    'Magento_Ui/js/lib/view/utils/async',
    'mage/translate'
], function (_, $) {
    'use strict';

    /**
     * Add labels to grouped inputs (street lines, etc)
     */
    return {
        init: function () {
            var self = this;

            $.async({
                selector: 'fieldset.field',
                ctx: $('.checkout-container').get(0)
            }, function (el) {
                _.defer(self.handle.bind(self), $(el));
            });
        },

        /**
         * @param  {jQuery} el
         * @return {void}
         */
        handle: function (el) {
            if (!el) {
                return;
            }

            var labelText = el.find('.label span').text().trim();
            if (!labelText) {
                return;
            }

            el.find('.field').each(function (i, el) {
                var label = $(this).find('.label').first();
                if (!label || label.text().trim()) {
                    return;
                }

                if (i > 0) {
                    labelText = labelText + ' ' + (i + 1);
                }

                label.prepend('<span>' + labelText + '</span>');
            });
        }
    }
});
