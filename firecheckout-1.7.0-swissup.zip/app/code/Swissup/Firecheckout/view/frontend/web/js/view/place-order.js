define([
    'jquery',
    'ko',
    'uiComponent',
    'Magento_Checkout/js/model/quote',
    'Swissup_Firecheckout/js/model/firecheckout'
], function($, ko, Component, quote, firecheckout) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Swissup_Firecheckout/place-order'
        },
        message: ko.observable(false),

        placeOrder: firecheckout.placeOrder.bind(firecheckout),

        initialize: function() {
            this._super();

            quote.paymentMethod.subscribe(function() {
                setTimeout(this.syncButtonState, 50);
            }. bind(this));

            // Virtual quote and Bread_BreadCheckout compatibility
            setInterval(this.syncButtonState, 1000);
        },

        /**
         * Sync button title and attributes.
         * Improves third-party modules compatibility.
         *
         * @return {void}
         */
        syncButtonState: function() {
            var placeOrder = $('.action.checkout', '.place-order'),
                span = placeOrder.find('span').first();

            // restore default values
            // if (span.attr('data-fc-text')) {
            //     span.text(span.attr('data-fc-text'));
            // }
            placeOrder.prop('disabled', false);
            placeOrder.removeClass('disabled');

            var method = quote.paymentMethod();
            if (!method || !method.method) {
                return;
            }

            var radio = $('#' + method.method),
                form = radio.parents('.payment-method'),
                button = $('.action.checkout', form);

            if (button.length) {
                // if (!span.attr('data-fc-text')) {
                //     span.attr('data-fc-text', placeOrder.find('span').text());
                // }
                // span.text(button.text());

                placeOrder.prop('disabled', button.prop('disabled'));
                placeOrder.toggleClass('disabled', button.hasClass('disabled'));
            }
        }
    });
});
