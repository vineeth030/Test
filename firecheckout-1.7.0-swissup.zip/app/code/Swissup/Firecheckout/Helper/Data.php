<?php

namespace Swissup\Firecheckout\Helper;

use Swissup\Firecheckout\Model\Config\Source\FormStyle;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var string
     */
    const CONFIG_PATH_ENABLED = 'firecheckout/general/enabled';

    /**
     * @var string
     */
    const CONFIG_PATH_URL_PATH = 'firecheckout/general/url_path';

    /**
     * @var string
     */
    const CONFIG_PATH_LAYOUT = 'firecheckout/general/layout';

    /**
     * @var string
     */
    const CONFIG_PATH_REDIRECT = 'firecheckout/general/redirect_to_checkout';

    /**
     * @var string
     */
    const CONFIG_PATH_PAGE_LAYOUT = 'firecheckout/design/page_layout';

    /**
     * @var string
     */
    const CONFIG_PATH_FORM_STYLE = 'firecheckout/design/form_style';

    /**
     * @var string
     */
    const CONFIG_PATH_HIDE_LABELS = 'firecheckout/design/hide_labels';

    /**
     * Retrieve isEnabled flag
     *
     * @return boolean
     */
    public function isFirecheckoutEnabled()
    {
        return $this->scopeConfig->getValue(
            self::CONFIG_PATH_ENABLED,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Retrieve firecheckout url path
     *
     * @return boolean
     */
    public function getFirecheckoutUrlPath()
    {
        return $this->scopeConfig->getValue(
            self::CONFIG_PATH_URL_PATH,
            \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE
        );
    }

    /**
     * Retrieve flag isRedirectToFirecheckout
     *
     * @return boolean
     */
    public function isRedirectToFirecheckoutEnabled()
    {
        return $this->scopeConfig->getValue(
            self::CONFIG_PATH_REDIRECT,
            \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE
        );
    }

    public function isOnFirecheckoutPage()
    {
        return $this->_getRequest()->getRouteName() === 'firecheckout';
    }

    /**
     * Get Firecheckout page url
     *
     * @return string
     */
    public function getFirecheckoutUrl()
    {
        return $this->_urlBuilder->getUrl(
            $this->getFirecheckoutUrlPath(),
            ['_secure' => true]
        );
    }

    /**
     * Get Firecheckout layout class name
     *
     * @return string
     */
    public function getLayoutClassNames()
    {
        $classes = $this->scopeConfig->getValue(
            self::CONFIG_PATH_LAYOUT,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return explode(' ', $classes);
    }

    /**
     * Get page layout config
     *
     * @return string
     */
    public function getPageLayout()
    {
        return $this->scopeConfig->getValue(
            self::CONFIG_PATH_PAGE_LAYOUT,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get page layout config
     *
     * @return string
     */
    public function getFormStyle()
    {
        return $this->scopeConfig->getValue(
            self::CONFIG_PATH_FORM_STYLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get hide_labels flag
     *
     * @return boolean
     */
    public function getHideLabels()
    {
        $value = $this->scopeConfig->getValue(
            self::CONFIG_PATH_HIDE_LABELS,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        if ($value) {
            $formStyle = $this->getFormStyle();
            if ($formStyle === FormStyle::HORIZONTAL) {
                $value = false;
            }
        }

        return $value;
    }

    /**
     * Get is visible labels
     *
     * @return boolean
     */
    public function getShowLabels()
    {
        return !$this->getHideLabels();
    }
}
