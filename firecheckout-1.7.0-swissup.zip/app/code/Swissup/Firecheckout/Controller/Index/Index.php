<?php

namespace Swissup\Firecheckout\Controller\Index;

class Index extends \Magento\Checkout\Controller\Index\Index
{
    //
}
