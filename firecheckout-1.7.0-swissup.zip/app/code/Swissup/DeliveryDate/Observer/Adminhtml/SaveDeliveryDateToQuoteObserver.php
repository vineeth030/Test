<?php

namespace Swissup\DeliveryDate\Observer\Adminhtml;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

use Swissup\DeliveryDate\Model\DeliverydateFactory;
use Swissup\DeliveryDate\Helper\Data as DataHelper;

/**
 * Class SaveDeliveryDateToQuoteObserver
 * @package Swissup\DeliveryDate\Model\Observer\Adminhtml
 */
class SaveDeliveryDateToQuoteObserver implements ObserverInterface
{

    /**
     * @var DeliverydateFactory
     */
    protected $deliverydateFactory;

    /**
     * @var \Swissup\DeliveryDate\Helper\Data
     */
    protected $dataHelper;

    /**
     *
     * @param DeliverydateFactory $deliverydateFactory
     */
    public function __construct(
        DeliverydateFactory $deliverydateFactory,
        DataHelper $dataHelper
    ) {
        $this->deliverydateFactory = $deliverydateFactory;
        $this->dataHelper = $dataHelper;
    }

    /**
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        $date = $observer->getRequestModel()->getParam('delivery_date');
        $date = $this->dataHelper->formatMySqlDateTime($date);

        if ($date) {
            $session = $observer->getSession();
            $orderId = $session->getOrderId();
            $quoteId = $session->getQuoteId();

            $modelDeliveryDate = $this->deliverydateFactory
                ->create()
                ->loadByOrderIdAndQuoteId($orderId, $quoteId);
            $modelDeliveryDate
                ->setDate($date)
                ->setOrderId($orderId)
                ->setQuoteId($quoteId)
                ->save();
        }
    }
}
