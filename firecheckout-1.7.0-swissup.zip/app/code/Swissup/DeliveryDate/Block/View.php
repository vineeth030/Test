<?php
namespace Swissup\DeliveryDate\Block;

use Magento\Framework\Registry;

use Swissup\DeliveryDate\Model\DeliverydateFactory;

class View extends \Magento\Framework\View\Element\Template
{
    /**
     * Core registry
     *
     * @var Registry
     */
    protected $coreRegistry;

    /**
     * @var DeliverydateFactory
     */
    protected $deliverydateFactory;

    /**
     * @var \Swissup\DeliveryDate\Helper\Data
     */
    public $helper;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param DeliverydateFactory $deliverydateFactory
     * @param \Swissup\DeliveryDate\Helper\Data $helper
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Registry $registry,
        DeliverydateFactory $deliverydateFactory,
        \Swissup\DeliveryDate\Helper\Data $helper,
        array $data = []
    ) {
        $this->coreRegistry = $registry;
        $this->deliverydateFactory = $deliverydateFactory;
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve current order model instance
     *
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->coreRegistry->registry('current_order');
    }

    public function getDeliveryDate()
    {
        $date = 'N/A';
        $deliveryDate = $this->deliverydateFactory
            ->create()
            ->loadByOrderId($this->getOrder()->getId());
        if ($deliveryDate->getId()) {
            $date = $deliveryDate->getDate();
            $date = $this->helper->getFormattedDate($date);
        }
        return $date;
    }
}
